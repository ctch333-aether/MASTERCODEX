# AETHER Kemetic Alchemy Design System Skill

## Overview
This skill enables creation of AETHER-branded interfaces using the Kemetic Alchemy design system. The system combines ancient Egyptian (Kemetic) aesthetics with retro-computing heritage (Windows 95, BYTE Magazine) and modern glassmorphism.

## When to Use
- Creating UI components for AETHER brand projects
- Building phygital experience interfaces
- Designing dashboards, knowledge bases, or content systems with Kemetic visual identity
- Any request mentioning "AETHER", "Kemetic", "phygital", or referencing the brand's visual DNA

## Core Principles

### Material Language (MANDATORY)
Every component must use one of these four materials:

1. **GLASSY** — Crystal-clear depth with interior luminescence
   - `backdrop-filter: blur(20px) saturate(180%)`
   - Interior gold glow animation
   - Classes: `card-glassy`, `card-glassy-cloud`, `card-glassy-aqua`

2. **SHEER** — Ethereal transparent layers
   - Progressive opacity: 8% → 5%
   - `backdrop-filter: blur(25px)`
   - Classes: `card-sheer`, `card-sheer-mist`, `card-sheer-layered`

3. **SOLID** — Crystalline chrome forms
   - Win95 beveled 3D borders
   - `border-color: highlight dark dark highlight`
   - Classes: `card-solid`, `card-solid-dragon`, `card-win95`

4. **IRIDESCENT** — Rainbow portal threshold
   - 8s infinite animation cycle
   - NO YELLOWS in spectrum
   - Classes: `card-iridescent`, `card-portal-shield`, `card-gem-iris`

### Color Law (CRITICAL)

**✓ APPROVED GOLD VALUES:**
```css
--kemetic-gold: #D4AF37;        /* Primary */
--kemetic-gold-bright: #CFB53B; /* Highlights */
--kemetic-gold-deep: #AA8C2C;   /* Deep accents */
--kemetic-gold-shimmer: #C9A227;/* Shimmer */
--ptah-gold: #D4AF37;           /* Sacred borders */
```

**✗ NEVER USE YELLOW:**
- NO `#FFFF00`, `#FFE66D`, `#F4E4BC`
- NO any hue between 50°-65° on color wheel
- Only metallic gold tones permitted

### Sacred Gems
```css
--gem-sapphire: #0F52BA;   /* Wisdom */
--gem-emerald: #2E8B57;    /* Rebirth */
--gem-amethyst: #9966CC;   /* Transformation */
--gem-turquoise: #40E0D0;  /* Joy */
--gem-lapis: #1E3A5F;      /* Truth */
--gem-ruby: #9B111E;       /* Power */
```

### Celestial Sky (from brand assets)
```css
--sky-zenith: #87CEEB;
--sky-azure: #6BB3D9;
--sky-mist: #B8D4E8;
--sky-cloud: #E8F4F8;
```

### Chrome System
```css
--crystal-chrome: #B8C4D0;
--liquid-chrome: #C8D8E8;
--phoenix-ice: #8AA8C8;
--facet-highlight: #E0ECF4;
```

## Required Elements

### Headers
- Use `--kemetic-pyramid` gradient background
- Include floating hieroglyphs: `𓂀 𓆣 ☥ 𓋹 𓅃`
- Title font: `var(--font-kemetic)` (Cinzel)
- Gold 4px bottom border

### Sections
- 4px top border with `var(--ptah-gold)`
- Background: `var(--glass-kemetic)` or `rgba(26, 26, 46, 0.6)`
- `backdrop-filter: blur(12px)`

### Footers
- Include "Believe®" text with metallic shimmer
- Blessing text: "ASE • ANKH • UDJA • SENEB"
- Floating hieroglyphs

## Animation Timings

```css
--ease-kemetic: cubic-bezier(0.175, 0.885, 0.32, 1.275);
--ease-chrome: cubic-bezier(0.22, 1, 0.36, 1);
--duration-shimmer: 4s;
--duration-iris: 8s;      /* Portal cycle MUST be 8s */
--duration-glow: 4s;
--duration-float: 6s;
```

## Typography Stack

```css
--font-kemetic: 'Cinzel', serif;           /* Headers, sacred text */
--font-display: 'Space Grotesk', sans-serif; /* UI labels */
--font-body: 'Inter', sans-serif;          /* Body copy */
--font-code: 'JetBrains Mono', monospace;  /* Code */
--font-win95: 'MS Sans Serif', Tahoma;     /* Retro UI */
```

## Required Font Import
```html
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&family=Cinzel:wght@400;500;600;700&display=swap" rel="stylesheet">
```

## Signature Gradients

```css
/* Always use these named gradients */
--kemetic-pyramid: linear-gradient(180deg, #D4AF37 0%, #1E3A5F 50%, #0f0f1a 100%);
--nile-flow: linear-gradient(180deg, #1E3A5F 0%, #4169E1 50%, #40E0D0 100%);
--quintessence: linear-gradient(45deg, #0F52BA, #9966CC, #2E8B57, #D4AF37);
--portal-iris: linear-gradient(90deg, #9B111E, #B5651D, #D4AF37, #2E8B57, #40E0D0, #4169E1, #9966CC, #1E3A5F);
--sacred-metals-shimmer: linear-gradient(135deg, #D4AF37 0%, #E5E4E2 25%, #D4AF37 50%, #E5E4E2 75%, #D4AF37 100%);
```

## Implementation Checklist

When creating AETHER interfaces:

- [ ] Import design tokens CSS or include `:root` variables
- [ ] Use only approved metallic gold values (NO YELLOWS)
- [ ] Apply one of four materials to each component
- [ ] Include 4px gold top-border on sections
- [ ] Use Cinzel font for headers
- [ ] Add hieroglyphic elements to header/footer
- [ ] Set iridescent animations to 8s duration
- [ ] Use Win95 beveled borders for SOLID material
- [ ] Include "Believe®" and blessing text in footer
- [ ] Implement `prefers-reduced-motion` support
- [ ] Add gold focus states for accessibility

## Quick Reference Card Classes

| Material | Primary | Variant 1 | Variant 2 |
|----------|---------|-----------|-----------|
| GLASSY | `card-glassy` | `card-glassy-cloud` | `card-glassy-aqua` |
| SHEER | `card-sheer` | `card-sheer-mist` | `card-sheer-layered` |
| SOLID | `card-solid` | `card-win95` | `card-solid-dragon` |
| IRIDESCENT | `card-iridescent` | `card-portal-shield` | `card-gem-iris` |
| KEMETIC | `card-kemetic` | `card-gem-sapphire` | `card-gem-emerald` |

## Button Classes

| Class | Style |
|-------|-------|
| `btn-gold` | Primary gold gradient |
| `btn-chrome` | Win95 3D beveled |
| `btn-sapphire` | Sapphire gem |
| `btn-iris` | Iridescent border |
| `btn-cloud` | Cloud glass |

## File Structure

```
aether-kemetic-final/
├── aether-kemetic-alchemy-ui.html  (Component library)
├── css/
│   └── aether-kemetic-tokens.css   (Design tokens)
├── assets/
│   └── AlchemistInstaStory1.gif    (Brand asset)
├── docs/
│   └── README.md                    (Documentation)
└── SKILL.md                         (This file)
```

## Example Usage

```html
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="css/aether-kemetic-tokens.css">
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600&family=Inter:wght@400;500&display=swap" rel="stylesheet">
</head>
<body style="background: var(--kemetic-obsidian-night); color: var(--kemetic-platinum);">
  
  <header style="background: var(--kemetic-pyramid); border-bottom: 4px solid var(--ptah-gold);">
    <h1 style="font-family: var(--font-kemetic); color: var(--kemetic-gold-bright);">
      ☥ AETHER Kemetic
    </h1>
  </header>
  
  <section class="section" style="border-top: 4px solid var(--ptah-gold);">
    <div class="card-glassy">
      <h2 class="card-title">GLASSY Material</h2>
      <p class="card-desc">Crystal depth with interior luminescence.</p>
    </div>
  </section>
  
  <footer style="text-align: center;">
    <div style="background: var(--sacred-metals-shimmer); -webkit-background-clip: text; color: transparent;">
      Believe®
    </div>
    <p>𓂀 𓆣 ☥ 𓋹 𓅃</p>
  </footer>
  
</body>
</html>
```

## Brand Philosophy

The AETHER Kemetic Alchemy design system embodies the company's mission to democratize transformative experiences. The fusion of ancient wisdom (Kemetic) with accessible technology (Win95, glassmorphism) creates interfaces that feel both timeless and familiar.

**Key Values:**
- **Accessibility** — Premium experience at accessible price points
- **Authenticity** — Real gold, real gems, real heritage
- **Innovation** — Phygital fusion of physical and digital
- **Equity** — Designed for 85% of population, not just 15%

---

*ASE • ANKH • UDJA • SENEB*

*𓂀 𓆣 ☥ 𓋹 𓅃*
