# ☥ AETHER KEMETIC ALCHEMY — Design System v5.0

> *"The flesh of the gods, rendered in silicon and light."*

A comprehensive design system synthesizing ancient Kemetic wisdom with retro-computing heritage and cutting-edge glassmorphism. This system powers AETHER's phygital experience platform with a distinctive visual language that democratizes transformative experiences through accessible, intentional design.

---

## 📚 Table of Contents

1. [Visual DNA Sources](#visual-dna-sources)
2. [Material Language](#material-language)
3. [Color Law](#color-law)
4. [Installation](#installation)
5. [Design Tokens](#design-tokens)
6. [Component Library](#component-library)
7. [Animation System](#animation-system)
8. [Typography](#typography)
9. [Accessibility](#accessibility)
10. [Brand Assets](#brand-assets)

---

## 🧬 Visual DNA Sources

This design system amalgamates four distinct visual heritages:

### AlchemistInstaStory1.gif
- **Chrome-glass clouds** — Organic blob morphing with interior bubble reflections
- **Iridescent portal frame** — Rainbow spectrum border cycling at 8s
- **Celestial dragon** — Crystalline chrome creature emerging from atmosphere
- **Sky atmosphere** — Soft whites, sky blues (#87CEEB), turquoise depths

### BYTE Magazine 1977
- **Crystal goblet** — Multi-layer chrome reflections with celestial glow
- **Celestial computing** — Deep blue atmosphere with star-like highlights
- **Chrome 3D orbs** — Metallic spheres with interior luminescence

### Macquarium Heritage
- **Retro tech + organic fusion** — Technology as vessel for living beauty
- **Win95 aesthetics** — Beveled 3D borders, system gray (#C0C0C0)
- **Bubble aquarium** — Floating organic elements in glass containers

### Kemetic Obelisk
- **Divine monumentality** — Vertical hierarchy, sacred geometry
- **Gold accents** — Ptah-gold (#D4AF37) borders and shimmer effects
- **Hieroglyphic elements** — 𓂀 𓆣 ☥ 𓋹 𓅃 as decorative motifs

---

## 🎨 Material Language

### GLASSY
Crystal-clear depth with interior luminescence.

```css
.card-glassy {
  background: var(--glass-crystal-bg);
  backdrop-filter: blur(var(--glass-blur)) saturate(var(--glass-saturate));
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 18px;
}
```

**Properties:**
- Multi-layer `backdrop-filter: blur(20px) saturate(180%)`
- Radial highlight at 30%/20% position: `var(--glass-crystal-highlight)`
- Interior gold glow: `var(--glass-crystal-inner-glow)`
- Animation: `interior-glow 4s ease-in-out infinite`

**Variants:**
- `card-glassy` — Standard crystal clear
- `card-glassy-cloud` — Chrome cloud with blob-morph (from brand GIF)
- `card-glassy-aqua` — Macquarium bubble effect

### SHEER
Ethereal transparent layers with weightless, vapor-like quality.

```css
.card-sheer {
  background: linear-gradient(180deg, 
    var(--sheer-start) 0%, 
    var(--sheer-end) 100%
  );
  backdrop-filter: blur(var(--sheer-blur));
  border: 1px solid rgba(255, 255, 255, 0.08);
}
```

**Properties:**
- Progressive opacity: 8% → 5%
- Blur: 25px
- Platinum top-edge highlight
- Minimal material presence

**Variants:**
- `card-sheer` — Standard vapor veil
- `card-sheer-mist` — Celestial atmosphere from brand GIF
- `card-sheer-layered` — Three stacked translucent planes

### SOLID
Crystalline chrome forms with sharp faceted reflections.

```css
.card-solid {
  background: linear-gradient(180deg, 
    var(--liquid-chrome) 0%, 
    var(--crystal-chrome) 30%, 
    var(--phoenix-ice) 60%, 
    var(--crystal-chrome-deep) 100%
  );
  border: 3px solid;
  border-color: var(--win95-highlight) var(--win95-dark) var(--win95-dark) var(--win95-highlight);
  box-shadow: var(--shadow-win95-raised);
}
```

**Properties:**
- Win95 beveled 3D borders
- Chrome surface gradient: liquid → crystal → phoenix-ice → deep
- 4px 4px offset shadow
- Surface reflection pseudo-element

**Variants:**
- `card-solid` — Standard chrome facet
- `card-solid-dragon` — Chrome creature with rotation animation
- `card-win95` — Authentic Windows 95 window with titlebar

### IRIDESCENT
Rainbow portal threshold with animated gem spectrum.

```css
.card-iridescent::before {
  background: var(--portal-iris);
  background-size: 400% 100%;
  animation: iris-flow 8s linear infinite;
}
```

**Properties:**
- 8s infinite cycle
- Spectrum: Ruby → Carnelian → Gold → Emerald → Turquoise → Sapphire → Amethyst → Lapis
- **NO YELLOWS** — Only metallic gold (#D4AF37)

**Variants:**
- `card-iridescent` — Standard portal gateway
- `card-portal-shield` — Shield shape from brand GIF
- `card-gem-iris` — Multi-gem pulsing glow

---

## 🎨 Color Law

### CRITICAL: NO YELLOWS — ONLY METALLIC GOLD

**✓ APPROVED Gold Values:**
| Token | Hex | Usage |
|-------|-----|-------|
| `--kemetic-gold` | `#D4AF37` | Primary gold |
| `--kemetic-gold-bright` | `#CFB53B` | Highlights |
| `--kemetic-gold-deep` | `#AA8C2C` | Deep accents |
| `--kemetic-gold-shimmer` | `#C9A227` | Shimmer effects |
| `--ptah-gold` | `#D4AF37` | Sacred borders |

**✗ PROHIBITED Yellow Values:**
- `#FFFF00` — Pure yellow
- `#FFE66D` — Pale yellow
- `#F4E4BC` — Cream yellow
- Any hue between 50°-65° on color wheel

### Sacred Gem Tones
| Gem | Primary | Light | Deep | Glow |
|-----|---------|-------|------|------|
| Sapphire | `#0F52BA` | `#4169E1` | `#0A3D8F` | `rgba(15, 82, 186, 0.6)` |
| Emerald | `#2E8B57` | `#3CB371` | `#1a4d3a` | `rgba(46, 139, 87, 0.6)` |
| Amethyst | `#9966CC` | `#B399D4` | `#7B4FB8` | `rgba(153, 102, 204, 0.6)` |
| Turquoise | `#40E0D0` | `#7FFFD4` | `#20B2AA` | `rgba(64, 224, 208, 0.6)` |
| Lapis | `#1E3A5F` | `#2E5A8F` | `#152942` | `rgba(30, 58, 95, 0.6)` |

### Celestial Sky (Brand GIF)
| Token | Hex | Description |
|-------|-----|-------------|
| `--sky-zenith` | `#87CEEB` | Top sky blue |
| `--sky-azure` | `#6BB3D9` | Mid atmosphere |
| `--sky-mist` | `#B8D4E8` | Misty layer |
| `--sky-cloud` | `#E8F4F8` | Cloud white |

### Crystal Chrome
| Token | Hex | Description |
|-------|-----|-------------|
| `--facet-highlight` | `#E0ECF4` | Brightest facet |
| `--liquid-chrome` | `#C8D8E8` | Liquid surface |
| `--crystal-chrome` | `#B8C4D0` | Standard chrome |
| `--phoenix-ice` | `#8AA8C8` | Cool chrome |
| `--portal-azure` | `#2D60A8` | Deep chrome |

---

## 📦 Installation

### Option 1: Link CSS Tokens
```html
<link rel="stylesheet" href="css/aether-kemetic-tokens.css">
```

### Option 2: Import in CSS
```css
@import 'css/aether-kemetic-tokens.css';
```

### Option 3: Copy Design Tokens
Copy the `:root` block from `aether-kemetic-tokens.css` into your project's CSS.

### Required Fonts
```html
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&family=Cinzel:wght@400;500;600;700&display=swap" rel="stylesheet">
```

---

## 🎛️ Design Tokens

### Token Tiers

| Tier | Category | Description |
|------|----------|-------------|
| 1 | Kemetic Metals | Gold spectrum, platinum, electrum |
| 2 | Sacred Gems | Sapphire, emerald, amethyst, turquoise, lapis |
| 3 | Celestial Sky | Brand GIF atmosphere colors |
| 4 | Crystal Chrome | SOLID material base colors |
| 5 | Obsidian Depths | Dark backgrounds |
| 6 | Win95 System | Retro interface colors |
| 7 | Iridescent Spectrum | Portal iris cycle (NO YELLOWS) |
| 8 | Glassy Material | GLASSY backdrop-filter tokens |
| 9 | Sheer Material | SHEER transparency tokens |
| 10 | Kemetic Glass | Combined glass + gold tokens |
| 11 | Gradients | Signature multi-color gradients |
| 12 | Shadows | Material-specific shadow systems |
| 13 | Typography | Font stacks |
| 14 | Animation | Timing functions and durations |
| 15 | Semantic | Application-level tokens |

---

## 🧩 Component Library

### Cards
| Class | Material | Description |
|-------|----------|-------------|
| `.card-glassy` | GLASSY | Crystal clear with interior glow |
| `.card-glassy-cloud` | GLASSY | Chrome cloud with blob morph |
| `.card-glassy-aqua` | GLASSY | Macquarium bubble effect |
| `.card-sheer` | SHEER | Vapor veil transparency |
| `.card-sheer-mist` | SHEER | Celestial atmosphere |
| `.card-sheer-layered` | SHEER | Three stacked planes |
| `.card-solid` | SOLID | Chrome facet with beveled edges |
| `.card-solid-dragon` | SOLID | Chrome creature animation |
| `.card-win95` | SOLID | Win95 window with titlebar |
| `.card-iridescent` | IRIDESCENT | Portal gateway border |
| `.card-portal-shield` | IRIDESCENT | Shield shape portal |
| `.card-gem-iris` | IRIDESCENT | Multi-gem pulsing |
| `.card-kemetic` | KEMETIC | Gold-bordered glass |
| `.card-gem-sapphire` | KEMETIC | Sapphire gem card |
| `.card-gem-emerald` | KEMETIC | Emerald gem card |
| `.card-gem-amethyst` | KEMETIC | Amethyst gem card |
| `.card-gem-turquoise` | KEMETIC | Turquoise gem card |

### Buttons
| Class | Style | Description |
|-------|-------|-------------|
| `.btn-gold` | KEMETIC | Primary gold action |
| `.btn-chrome` | SOLID | Win95 3D button |
| `.btn-sapphire` | GEM | Sapphire gradient |
| `.btn-iris` | IRIDESCENT | Portal border button |
| `.btn-cloud` | GLASSY | Cloud glass button |

### Other Components
- `.chrome-orb` — 3D metallic sphere with ankh
- `.progress-bar` + `.progress-fill` — Quintessence gradient progress
- `.swatch` — Color palette specimen

---

## ⚡ Animation System

| Keyframe | Duration | Purpose |
|----------|----------|---------|
| `metallic-shimmer` | 4-8s | Gold/platinum gradient shift |
| `chrome-pulse` | 4s | Orb glow intensity |
| `kemetic-glow` | 4s | Sacred shadow pulsation |
| `iris-flow` | 8s | Portal border cycle |
| `interior-glow` | 4s | Interior luminescence |
| `cloud-float` | 6s | Organic floating motion |
| `gem-cycle` | 6s | Multi-gem glow rotation |
| `hieroglyph-float` | 6s | Symbol hover animation |
| `ankh-pulse` | 3s | Sacred symbol activation |
| `blob-morph` | 12s | Organic shape transformation |
| `dragon-hover` | 10s | Chrome creature rotation |

### Timing Functions
```css
--ease-kemetic: cubic-bezier(0.175, 0.885, 0.32, 1.275); /* Bounce */
--ease-chrome: cubic-bezier(0.22, 1, 0.36, 1);          /* Smooth */
--ease-float: cubic-bezier(0.4, 0, 0.2, 1);             /* Gentle */
```

---

## 📝 Typography

| Token | Stack | Usage |
|-------|-------|-------|
| `--font-kemetic` | Cinzel, Times New Roman, serif | Headers, sacred text |
| `--font-display` | Space Grotesk, Inter, sans-serif | Display, UI labels |
| `--font-body` | Inter, -apple-system, sans-serif | Body copy |
| `--font-code` | JetBrains Mono, Fira Code, monospace | Code, technical |
| `--font-win95` | MS Sans Serif, Tahoma, sans-serif | Retro UI |

---

## ♿ Accessibility

### Motion Reduction
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

### High Contrast
```css
@media (prefers-contrast: more) {
  :root {
    --glass-crystal-bg: rgba(26, 26, 46, 0.95);
    --sheer-start: rgba(26, 26, 46, 0.9);
  }
}
```

### Focus States
```css
*:focus-visible {
  outline: 3px solid var(--kemetic-gold-bright);
  outline-offset: 3px;
  box-shadow: 0 0 15px rgba(212, 175, 55, 0.5);
}
```

---

## 📁 Brand Assets

### Included Files
- `aether-kemetic-alchemy-ui.html` — Complete component library
- `css/aether-kemetic-tokens.css` — Standalone design tokens
- `assets/AlchemistInstaStory1.gif` — Brand visual DNA source

### Brand Guidelines
1. **Always** use 4px top-border with `--ptah-gold` on Kemetic cards
2. **Never** use yellow (#FFFF00 family) — only metallic gold
3. **Always** cycle iridescent borders at 8s intervals
4. **Always** maintain Win95 border order: highlight, dark, dark, highlight
5. **Always** include hieroglyphic elements in headers/footers

---

## 📜 License

AETHER Kemetic Alchemy Design System © 2025 Alchemist Atelier / AETHER
Part of the Phygital Operating System initiative.

**Believe®**

---

*𓂀 𓆣 ☥ 𓋹 𓅃*

*ASE • ANKH • UDJA • SENEB*
